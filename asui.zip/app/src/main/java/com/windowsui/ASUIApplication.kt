package com.windowsui

import android.app.Application
import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ASUIApplication : Application() {

    companion object {
        private lateinit var instance: ASUIApplication
        fun getInstance(): ASUIApplication = instance
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        Log.d("ASUIApplication", "Uygulama başlatıldı")
        
        // Tüm yöneticileri başlat
        SystemState.loadState(this)
        TaskbarState.loadState(this)
        WindowState.loadState(this)
        NotificationState.init(this)
        PermissionManager.init(this)
        TaskbarPosition.init(this)
        WallpaperManager.init(this)
        WifiController.init(this)
        UsbOtgManager.initialize(this)
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
    BinaryManager.initialize(this@ASUIApplication)
}
    }

    fun getAppContext(): Context = applicationContext
}