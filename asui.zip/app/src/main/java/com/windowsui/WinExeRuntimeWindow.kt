package com.windowsui

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/**
 * First-stage ASUI integration surface for Windows EXE files.
 * The UI is intentionally honest: it does not pretend to run EXEs until the
 * bundled Wine/Box64/RootFS runtime has been integrated and verified.
 */
@Composable
fun WinExeRuntimeWindow(onClose: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedExe by remember { mutableStateOf<File?>(null) }
    var status by remember {
        mutableStateOf(
            if (WinExeRuntimeManager.isReady(context)) {
                "Uyumluluk altyapısı hazır."
            } else {
                "Çalıştırma altyapısı henüz ASUI paketine eklenmedi."
            }
        )
    }
    var busy by remember { mutableStateOf(false) }
    var runtimeReady by remember { mutableStateOf(WinExeRuntimeManager.isReady(context)) }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            busy = true
            status = "EXE dosyası ASUI alanına kopyalanıyor…"
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    WinExeRuntimeManager.importExe(context, uri)
                }
                selectedExe = result.getOrNull()
                status = result.fold(
                    onSuccess = { "Dosya hazır: ${it.name}" },
                    onFailure = { it.message ?: "Dosya alınamadı." }
                )
                runtimeReady = WinExeRuntimeManager.isReady(context)
                busy = false
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Windows Uygulamaları", style = MaterialTheme.typography.titleLarge)
        Text(
            "Windows .exe dosyalarını ASUI Desktop içinden seçmek için başlangıç ekranı.",
            style = MaterialTheme.typography.bodyMedium
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Uyumluluk altyapısı", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (runtimeReady) {
                        "Winlator tabanlı çalışma paketi bulundu. Gerçek başlatma köprüsü sonraki entegrasyon adımında doğrulanmalı."
                    } else {
                        "Eksik: ASUI uygulamasının kendi içinde Wine + Box64 + gerekli rootfs/kitaplıklar ve başlatma köprüsü. Winlator uygulamasının telefona ayrıca kurulması hedeflenmiyor."
                    },
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { filePicker.launch(arrayOf("*/*")) },
                enabled = !busy
            ) { Text(".exe Dosyası Seç") }
            OutlinedButton(onClick = onClose) { Text("Kapat") }
        }

        selectedExe?.let { file ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Seçilen dosya", style = MaterialTheme.typography.titleSmall)
                    Text(file.name, style = MaterialTheme.typography.bodyMedium)
                    Text("Boyut: ${formatBytes(file.length())}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        Text(status, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(4.dp))
        Button(
            onClick = {
                status = "Dosya seçimi hazır. EXE çalıştırma, uygulama içine yerel uyumluluk motoru ve grafik/işlem başlatma köprüsü eklendikten sonra etkinleştirilecek."
            },
            enabled = selectedExe != null && runtimeReady,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Çalıştır") }

        Text(
            "Not: EXE seçme desteği tek başına Windows programlarını çalıştırmaz. Android ARM64 için uyumluluk katmanı, yerel ikili dosyalar, rootfs ve görüntü/ses/girdi köprüsü gerekir.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024L * 1024L * 1024L -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
    else -> "%.2f GB".format(bytes / (1024.0 * 1024.0 * 1024.0))
}

/** App-private storage bridge; no broad storage permission is needed to import a file. */
object WinExeRuntimeManager {
    private fun baseDir(context: Context) = File(context.filesDir, "winlator-runtime")
    private fun programsDir(context: Context) = File(baseDir(context), "programs")

    /** Marker is written only by a future runtime installer after all payload checks pass. */
    fun isReady(context: Context): Boolean {
        val root = baseDir(context)
        return File(root, ".asui-runtime-ready").isFile &&
            File(root, "launch-exe.sh").isFile &&
            File(root, "rootfs").isDirectory
    }

    fun importExe(context: Context, uri: Uri): Result<File> = runCatching {
        val displayName = queryDisplayName(context, uri)
            ?: uri.lastPathSegment?.substringAfterLast('/')
            ?: "selected.exe"
        val safeName = displayName.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("[^A-Za-z0-9._() -]"), "_")
            .take(120)
        require(safeName.endsWith(".exe", ignoreCase = true)) {
            "Lütfen .exe uzantılı bir Windows programı seç."
        }
        val dir = programsDir(context)
        if (!dir.exists() && !dir.mkdirs()) throw IOException("Uygulama dosya alanı oluşturulamadı.")
        val destination = File(dir, safeName)
        context.contentResolver.openInputStream(uri)?.use { input ->
            destination.outputStream().buffered().use { output -> input.copyTo(output) }
        } ?: throw IOException("Seçilen dosya okunamadı.")
        require(destination.isFile && destination.length() > 0L) { "Dosya boş veya kopyalanamadı." }
        destination
    }

    private fun queryDisplayName(context: Context, uri: Uri): String? =
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) cursor.getString(index) else null
                } else null
            }
}
