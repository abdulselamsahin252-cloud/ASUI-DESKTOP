package com.winlator.renderer.effects;

import com.winlator.renderer.material.ScreenMaterial;

public class CRTEffect extends Effect {
    @Override
    protected ScreenMaterial createMaterial() {
        return new ScreenMaterial() {
            @Override
            protected String getFragmentShader() {
                return String.join("\n",
                    "precision highp float;",

                    "#define CA_AMOUNT 1.0025",
                    "#define SCANLINE_INTENSITY_X 0.125",
                    "#define SCANLINE_INTENSITY_Y 0.375",
                    "#define SCANLINE_SIZE 1024.0",

                    "uniform sampler2D screenTexture;",
                    "in vec2 vUV;",

                    "layout(location = 0) out vec4 outFragColor;",

                    "void main() {",
                        "vec4 finalColor = texture(screenTexture, vUV);",

                        "finalColor.rgb = vec3(",
                            "texture(screenTexture, (vUV - 0.5) * CA_AMOUNT + 0.5).r,",
                            "finalColor.g,",
                            "texture(screenTexture, (vUV - 0.5) / CA_AMOUNT + 0.5).b",
                        ");",

                        "float scanlineX = abs(sin(vUV.x * SCANLINE_SIZE) * 0.5 * SCANLINE_INTENSITY_X);",
                        "float scanlineY = abs(sin(vUV.y * SCANLINE_SIZE) * 0.5 * SCANLINE_INTENSITY_Y);",

                        "outFragColor = vec4(mix(finalColor.rgb, vec3(0.0), scanlineX + scanlineY), finalColor.a);",
                    "}"
                );
            }
        };
    }
}
